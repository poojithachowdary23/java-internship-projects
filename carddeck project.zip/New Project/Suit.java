// Suit.java
public enum Suit {
    SPADE, CLUB, HEART, DIAMOND;
}

