// CardComparator.java
import java.util.Comparator;

public class CardComparator implements Comparator<Card> {

    @Override
    public int compare(Card card1, Card card2) {
        // Define the colors: Red (HEART, DIAMOND), Black (SPADE, CLUB)
        int color1 = (card1.getSuit() == Suit.HEART || card1.getSuit() == Suit.DIAMOND) ? 1 : 0;
        int color2 = (card2.getSuit() == Suit.HEART || card2.getSuit() == Suit.DIAMOND) ? 1 : 0;

        // Compare by color first
        if (color1 != color2) {
            return color1 - color2;
        }

        // If colors are the same, compare by suit
        int suitComparison = card1.getSuit().compareTo(card2.getSuit());
        if (suitComparison != 0) {
            return suitComparison;
        }

        // If suits are the same, compare by rank
        return card1.getRank().getValue() - card2.getRank().getValue();
    }
}

