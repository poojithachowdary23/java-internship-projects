// Main.java

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Deck deck = new Deck();
        deck.shuffle();

        // Draw 20 random cards
        List<Card> drawnCards = deck.drawMultiple(20);

        // Project done by
        System.out.println("------------------------------------");
        System.out.println("T. POOJITHA");
        System.out.println("ppoojithachowdary8@gmail.com");
        System.out.println("------------------------------------");


        // Print drawn cards before sorting
        System.out.println("Project OUTPUT:");
        System.out.println("Drawn Cards (Before Sorting):");
        drawnCards.forEach(System.out::println);

        // Sort the drawn cards using the custom comparator
        Collections.sort(drawnCards, new CardComparator());

        // Print drawn cards after sorting
        System.out.println("\nDrawn Cards (After Sorting):");
        drawnCards.forEach(System.out::println);
    }
}
